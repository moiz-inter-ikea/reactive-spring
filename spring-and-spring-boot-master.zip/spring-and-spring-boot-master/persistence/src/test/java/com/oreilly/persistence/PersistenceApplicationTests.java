package com.oreilly.persistence;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class PersistenceApplicationTests {

    @Test
    public void contextLoads() {
    }

}
