package com.oreilly.reactiveofficers;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReactiveOfficersApplication {

    public static void main(String[] args) {
        SpringApplication.run(ReactiveOfficersApplication.class, args);
    }
}
